from Guest import Guest 
from room import Room 
from datetime import date 
from charge import Charge 

# Class Booking
class Booking:
    def __init__(self, id: int, guest: 'Guest', room: 'Room', start_date: date, end_date: date):
        self.id = id
        self.guest = guest
        self.room = room
        self.start_date = start_date
        self.end_date = end_date
        self.charges = []  # List of Charge objects
        self.is_paid = False

    def calculateCharges(self):
        # Assuming a simple per-day rate for the room
        num_days = (self.end_date - self.start_date).days
        total_charge = num_days * self.room.rate
        self.charges.append(Charge(len(self.charges) + 1, self, "Room charge", total_charge))