class Promotion:
    def __init__(self, id: int, description: str, discountRate: float):
        self.id = id
        self.description = description
        self.discountRate = discountRate

    def createPromotion(self):
        print(f"Promotion created: {self.description} with a discount rate of {self.discountRate}")