from user import ABC
from utils import hash_password

class Authentication(ABC):
    def authenticate(self, username: str, password: str) -> bool:
        pass

    def changePassword(self, old_password: str, new_password: str) -> bool:
        pass

# Class User
class User(Authentication):
        
    def __init__(self, id: int, username: str, password: str, role: str):
        self.id = id
        self.username = username
        self.password = hash_password(password)  # Store hashed password
        self.role = role

    def login(self, input_username, input_password):
        input_password_hashed = hash_password(input_password)
        if input_username == self.username and input_password_hashed == self.password:
            print(f"User {self.username} logged in successfully.")
            return True
        else:
            print("Login failed.")
            return False

    def logout(self):
        print(f"User {self.username} logged out.")

    def changePassword(self, old_password, new_password):
        old_password_hashed = hash_password(old_password)
        if self.password == old_password_hashed:
            self.password = hash_password(new_password)
            print("Password changed successfully.")
            return True
        else:
            print("Old password is incorrect.")
            return False
    
    def authenticate(self, input_username, input_password):
        input_password_hashed = hash_password(input_password)
        if self.username == input_username and self.password == input_password_hashed:
            print(f"User {self.username} logged in successfully.")
            return True
        else:
            print("Invalid username or password.")
            return False    