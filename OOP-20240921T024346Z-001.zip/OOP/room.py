from datetime import date 
from booking import Booking 

# Class Room
class Room:
    def __init__(self, id: int, number: str, type: str, rate: float):
        self.id = id
        self.number = number
        self.type = type
        self.rate = rate
        self.bookings = []  # List of Booking objects

    def checkAvailability(self, start_date: date, end_date: date) -> bool:
        for booking in self.bookings:
            if not (end_date <= booking.start_date or start_date >= booking.end_date):
                return False
        return True

    def assignRoom(self, booking: Booking):
        self.bookings.append(booking)