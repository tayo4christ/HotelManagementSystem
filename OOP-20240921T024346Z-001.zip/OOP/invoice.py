from booking import Booking
from Guest import Guest
from charge import Charge 
from typing import List, Optional

# Class Invoice
class Invoice:
    def __init__(self, id: int, guest: Guest, bookings: List[Booking], charges: List[Charge]):
        self.id = id
        self.guest = guest
        self.bookings = bookings
        self.charges = charges
        self.totalAmount = sum(charge.amount for charge in charges)
        self.is_paid = False

    def generateInvoice(self):
        # Generate and return invoice details (simplified)
        return {
            "Invoice ID": self.id,
            "Guest": self.guest.name,
            "Total Amount": self.totalAmount,
            "Is Paid": self.is_paid
        }

    def sendInvoice(self):
        # Simulate sending the invoice by email
        print(f"Sending invoice ID {self.id} to {self.guest.email}...")
        print("Invoice sent successfully.")

    def viewInvoice(self):
        print("\n--- Invoice Details ---")
        print(f"Invoice ID: {self.id}")
        print(f"Guest: {self.guest.name}")
        print("Bookings:")
        for booking in self.bookings:
            print(f"  Booking ID: {booking.id}, Room: {booking.room.number}, Dates: {booking.start_date} to {booking.end_date}")
        print("Charges:")
        for charge in self.charges:
            print(f"  {charge.description}: {charge.amount}")
        print(f"Total Amount: {self.totalAmount}")
        print(f"Paid: {'Yes' if self.is_paid else 'No'}")