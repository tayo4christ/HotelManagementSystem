from datetime import date

# Class Report
class Report:
    def __init__(self, id: int, type: str, start_date: date, end_date: date, data: str):
        self.id = id
        self.type = type
        self.start_date = start_date
        self.end_date = end_date
        self.data = data

    def generateReport(self):
        # Example of generating a simple report
        self.data = f"Report {self.id} of type {self.type} from {self.start_date} to {self.end_date}"
        # In a real application, this method would aggregate data and perform analysis as required
        print("Report generated successfully.")

    def viewReport(self):
        if not self.data:
            print("No report data available. Please generate the report first.")
            return
        # Display the report data
        print(f"\nViewing Report: {self.id}")
        print(self.data)
