from booking import Booking
from typing import List, Optional
from invoice import Invoice 
from report import Report 
from user import User 
from datetime import date 
from person import Person 
from notification import Notification 


# Class Staff
class Staff(Person, Notification):
    def __init__(self, id: int, name: str, email: str, role: str):
        super().__init__(id, name, email)
        self.role = role
    
    def sendNotification(self, message: str):
        print(f"Notification for Staff {self.id} - {self.role}: {message}")

    def manageBookings(self, bookings: List[Booking]):
        print("Managing Bookings:")
        for booking in bookings:
            # Example logic: print booking details
            print(f"Booking ID: {booking.id}, Guest: {booking.guest.name}, Room: {booking.room.number}, Dates: {booking.start_date} to {booking.end_date}")

    def generateInvoices(self, bookings: List[Booking]):
        invoices = []
        for booking in bookings:
            booking.calculateCharges()
            invoice = Invoice(len(invoices) + 1, booking.guest, [booking], booking.charges)
            invoices.append(invoice)
            print(f"Invoice generated for Booking ID: {booking.id}")
        return invoices

    def processPayments(self, invoices: List[Invoice]):
        for invoice in invoices:
            if not invoice.is_paid:
                invoice.is_paid = True
                for booking in invoice.bookings:
                    booking.is_paid = True
                print(f"Payment processed for Invoice ID: {invoice.id}")

    def generateReports(self, report_type: str, start_date: date, end_date: date, data: str):
        report = Report(len(data), report_type, start_date, end_date, data)
        report.generateReport()
        return report

    def manageUsers(self, users: List[User], action: str, user: Optional[User] = None):
        if action == "add" and user:
            users.append(user)
            print(f"User {user.username} added.")
        elif action == "remove" and user:
            users = [u for u in users if u.id != user.id]
            print(f"User {user.username} removed.")
        elif action == "list":
            for user in users:
                print(f"User ID: {user.id}, Username: {user.username}, Role: {user.role}")
        else:
            print("Invalid action or user data.")