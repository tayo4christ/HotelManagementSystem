import hashlib

def hash_password(password):
    return "hashed_" + password