from abc import ABC, abstractmethod

class Service(ABC):
    @abstractmethod
    def requestService(self, guest: 'Guest', service_details: str):
        pass

class RoomService(Service):
    def requestService(self, guest: 'Guest', service_details: str):
        print(f"Room service requested by Guest ID {guest.id}. Details: {service_details}")

class LaundryService(Service): 
    def requestService(self, guest: 'Guest', service_details: str):
        print(f"Laundry service requested by Guest ID {guest.id}. Details: {service_details}")

class FoodService(Service):
    def requestService(self, guest: 'Guest', service_details: str):
        print(f"Food service requested by Guest ID {guest.id}. Details: {service_details}")

from Guest import Guest 