from person import Person
from service import RoomService, LaundryService, FoodService
from Guest import Guest
from invoice import Invoice 
from room import Room
from booking import Booking
from staff import Staff 
from report import Report
from utils import hash_password
from user import User
from maintenance import Maintenance 
from feedback import Feedback 
from promotion import Promotion


# Main Menu
def main_menu():
    users = []  # List to store User objects
    guests = []  # List to store Guest objects
    staff_members = []  # List to store Staff objects
    rooms = [Room(i, f"Room {i}", "Standard", 100.0 + i * 10) for i in range(1, 11)]  # Sample rooms
    bookings = []  # List to store Booking objects
    invoices = []  # List to store Invoice objects
    reports = []  # List to store Report objects
    maintenances = []
    feedbacks = []
    promotions = []

    while True:
        print("\nWelcome to the Hotel Management System")
        print("1. Guest Operations")
        print("2. Staff Operations")
        print("3. User Operations")
        print("4. Add New Guest")
        print("5. List All Guests")
        print("6. Add New Staff Member")
        print("7. Maintenance Request")
        print("8. Feedback")
        print("9. Promotions")
        print("10. Exit")
        choice = input("Enter your choice: ")

        if choice == "1":
            guest_operations(guests, rooms, bookings, invoices)
        elif choice == "2":
            staff_operations(staff_members, bookings, invoices, reports)
        elif choice == "3":
            user_operations(users)
        elif choice == "4":
            add_guest(guests)
        elif choice =="5":
            list_guests(guests)
        elif choice == "6":
            create_staff_member(staff_members)
        elif choice == "7":
            handle_maintenance(maintenances, rooms)
        elif choice == "8":
            handle_feedback(feedbacks, guests)
        elif choice == "9":
            handle_promotion(promotions)
        elif choice == "10":
            print("Exiting the system.")
            break
        else:
            print("Invalid choice. Please try again.")

# Create instances of service classes
room_service = RoomService()
laundry_service = LaundryService()
food_service = FoodService()

def guest_operations(guests, rooms, bookings, invoices):
    while True:
        print("\n--- Guest Operations ---")
        print("1. Make a booking")
        print("2. View my invoices")
        print("3. Request Room Service")
        print("4. Reguest Laundry Service")
        print("5. Request Food Service")
        print("6. Exit to main menu")
        choice = input("Choose an operation: ")

        if choice == "1":
            make_guest_booking(guests, rooms, bookings)
        elif choice == "2":
            view_guest_invoices(guests, invoices)
        elif choice == "3":
            request_service(guests, room_service, "Room Service")
        elif choice == "4":
            request_service(guests, laundry_service, "Laundry Service")
        elif choice == "5":
            request_service(guests, food_service, "Food Service")
        elif choice == "6":
            break
        else:
            print("Invalid choice. Please try again.")

def request_service(guests, service, service_type):
    guest_id = input("Enter your guest ID: ")
    guest = next((g for g in guests if str(g.id) == guest_id), None)

    if not guest:
        print("Guest not found.")
        return

    service_details = input(f"Enter details for {service_type}: ")
    service.requestService(guest, service_details)
    guest.sendNotification(f"{service_type} requested: {service_details}")


def view_my_invoices(guests, invoices):
    guest_id = input("Enter your guest ID: ")
    guest = next((g for g in guests if str(g.id) == guest_id), None)

    if not guest:
        print("Guest not found.")
        return

    guest_invoices = [invoice for invoice in invoices if invoice.guest.id == guest.id]
    if not guest_invoices:
        print("No invoices found for this guest.")
        return

    for invoice in guest_invoices:
        invoice.viewInvoice()

def add_guest(guests):
    print("---- Add New Guest ----")
    guest_id = len(guests) + 1  # Simple way to generate a new ID
    name = input("Enter guest's name: ")
    email = input("Enter guest's email: ")
    phone = input("Enter guest's phone number: ")
    address = input("Enter guest's address: ")

    new_guest = Guest(guest_id, name, email, phone, address)
    guests.append(new_guest)
    print(f"Guest {name} added with ID: {guest_id}")

def list_guests(guests):
    if not guests:
        print("No guests are registered.")
        return
    print("\nRegistered Guests:")
    for guest in guests:
        print(f"ID: {guest.id}, Name: {guest.name}")

def make_guest_booking(guests, rooms, bookings):
    print("---- Make a Booking ----")
    
    # Select a guest
    guest_id = input("Enter guest ID: ")
    guest = next((g for g in guests if g.id == int(guest_id)), None)
    if not guest:
        print("Guest not found.")
        return

    # List available rooms and select one
    print("Available rooms:")
    for room in rooms:
        print(f"Room Number: {room.number}, Type: {room.type}, Rate: {room.rate}")
    room_number = input("Enter room number for booking: ")
    selected_room = next((r for r in rooms if r.number == room_number), None)
    if not selected_room:
        print("Room not found.")
        return

    # Enter booking dates
    start_date = input("Enter start date (YYYY-MM-DD): ")
    end_date = input("Enter end date (YYYY-MM-DD): ")

    # Create a new booking
    new_booking = Booking(len(bookings) + 1, guest, selected_room, start_date, end_date)
    bookings.append(new_booking)
    guest.bookings.append(new_booking)
    selected_room.bookings.append(new_booking)

    print(f"Booking successful! Booking ID: {new_booking.id}")

def view_guest_invoices(guests, invoices):
    print("---- View My Invoices ----")

    # Select a guest
    guest_id = input("Enter your guest ID: ")
    guest = next((g for g in guests if g.id == int(guest_id)), None)
    if not guest:
        print("Guest not found.")
        return

    # Display invoices for the guest
    guest_invoices = [invoice for invoice in invoices if invoice.guest.id == guest.id]
    if not guest_invoices:
        print("No invoices found.")
        return

    for invoice in guest_invoices:
        print(f"Invoice ID: {invoice.id}, Total Amount: {invoice.totalAmount}, Paid: {'Yes' if invoice.is_paid else 'No'}")

def staff_operations(staff_members, bookings, invoices, reports):
    print("---- Staff Login ----")
    staff_id = input("Enter your staff ID: ")
    staff_member = next((s for s in staff_members if str(s.id) == staff_id), None)

    if not staff_member:
        print("Invalid staff ID.")
        return

    while True:
        print("\n--- Staff Operations ---")
        print("1. Manage bookings")
        print("2. Generate a new report")
        print("3. View an existing report")
        print("4. Send an Invoice")
        print("5. Exit to main menu")
        choice = input("Choose an operation: ")

        if choice == "1":
            manage_bookings(staff_members, bookings)
        elif choice == "2":
            generate_new_report(reports)
        elif choice == "3":
            view_existing_report(reports)
        elif choice == "4":
            send_invoice(invoices)
        elif choice == "5":
            break
        else:
            print("Invalid choice. Please try again.")

def create_staff_member(staff_members):
    print("---- Create New Staff Member ----")
    staff_id = len(staff_members) + 1  # Simple ID generation
    name = input("Enter staff member's name: ")
    email = input("Enter staff member's email: ")
    role = input("Enter staff member's role: ")

    new_staff_member = Staff(staff_id, name, email, role)
    staff_members.append(new_staff_member)
    print(f"Staff member {name} created with ID: {staff_id}")

def send_invoice(invoices):
    if not invoices:
        print("No invoices to send.")
        return

    invoice_id = input("Enter the Invoice ID to send: ")
    invoice = next((inv for inv in invoices if str(inv.id) == invoice_id), None)

    if invoice:
        invoice.sendInvoice()
    else:
        print("Invoice not found.")

def manage_bookings(staff_members, bookings):
    print("---- Manage Bookings ----")

    # Assuming a staff member is already logged in or identified
    staff_id = input("Enter your staff ID: ")
    staff_member = next((s for s in staff_members if s.id == int(staff_id)), None)
    if not staff_member:
        print("Staff member not found.")
        return

    print("All Bookings:")
    for booking in bookings:
        print(f"Booking ID: {booking.id}, Guest ID: {booking.guest.id}, Room: {booking.room.number}, Start Date: {booking.start_date}, End Date: {booking.end_date}, Paid: {'Yes' if booking.is_paid else 'No'}")

    # Example operation: Cancel a booking
    booking_id = input("Enter Booking ID to cancel (or leave blank to return): ")
    if booking_id:
        booking_to_cancel = next((b for b in bookings if b.id == int(booking_id)), None)
        if booking_to_cancel:
            bookings.remove(booking_to_cancel)
            print(f"Booking {booking_id} cancelled.")
        else:
            print("Booking not found.")

def generate_new_report(reports):
    report_id = len(reports) + 1
    report_type = input("Enter report type: ")
    start_date = input("Enter start date (YYYY-MM-DD): ")
    end_date = input("Enter end date (YYYY-MM-DD): ")
    
    new_report = Report(report_id, report_type, start_date, end_date, "")
    new_report.generateReport()
    reports.append(new_report)
    print(f"Report {report_id} generated.")

def view_existing_report(reports):
    if not reports:
        print("No reports available.")
        return

    report_id = input("Enter report ID to view: ")
    report = next((r for r in reports if str(r.id) == report_id), None)

    if report:
        report.viewReport()
    else:
        print("Report not found.")


def user_operations(users):
    while True:
        print("\n--- User Operations ---")
        print("1. Login")
        print("2. Create user")
        print("3. Change Password")
        print("4. Exit to main menu")
        choice = input("Choose an operation: ")

        if choice == "1":
            user_login(users)
        elif choice == "2":
            create_user(users)
        elif choice == "3":
            username = input("Enter username: ")
            old_password = input("Enter old password: ")
            new_password = input("Enter new password: ")
            user = next((u for u in users if u.username == username), None)
            if user and user.changePassword(old_password, new_password):
                print("Password changed successfully.")
            else:
                print("Password change failed.")
        elif choice == "4":
            break
        else:
            print("Invalid choice. Please try again.")

def user_login(users):
    print("---- User Login ----")

    username = input("Enter username: ")
    password = input("Enter password: ")
    hashed_password = hash_password(password)  # Hash the input password

    # Checking if the user exists and password is correct
    user = next((u for u in users if u.username == username and u.password == hashed_password), None)
    if user:
        print(f"Welcome {user.username}! Login successful.")
        return user
    else:
        print("Login failed. Invalid username or password.")
        return None


def create_user(users):
    print("---- Create New User ----")

    user_id = len(users) + 1  # Simple ID generation, incrementing the last user's ID
    username = input("Enter new username: ")
    password = input("Enter new password: ")
    role = input("Enter role (guest/staff): ")

    # Checking if the username already exists
    if any(u.username == username for u in users):
        print("A user with this username already exists.")
        return

    new_user = User(user_id, username, password, role)
    users.append(new_user)
    print(f"User {username} created successfully. User ID is {new_user.id}.")

def handle_maintenance(maintenances, rooms):
    print("\n--- Maintenance Management ---")
    print("1. Create Maintenance Request")
    print("2. Schedule Maintenance")
    print("3. Complete Maintenance")
    print("4. Return to Main Menu")
    choice = input("Enter your choice: ")

    if choice == "1":
        room_number = input("Enter Room Number for Maintenance: ")
        description = input("Enter Maintenance Description: ")
        room = next((r for r in rooms if r.number == room_number), None)
        if room:
            new_maintenance = Maintenance(len(maintenances) + 1, room, description)
            maintenances.append(new_maintenance)
            print(f"Created Maintenance Request ID: {new_maintenance.id}")
        else:
            print("Room not found.")
    elif choice == "2":
        maintenance_id = input("Enter Maintenance ID to schedule: ")
        maintenance = next((m for m in maintenances if str(m.id) == maintenance_id), None)
        if maintenance:
            maintenance.scheduleMaintenance()
        else:
            print("Maintenance request not found.")
    elif choice == "3":
        maintenance_id = input("Enter Maintenance ID to complete: ")
        maintenance = next((m for m in maintenances if str(m.id) == maintenance_id), None)
        if maintenance:
            maintenance.completeMaintenance()
        else:
            print("Maintenance request not found.")
    elif choice == "4":
        return


def handle_feedback(feedbacks, guests):
    print("\n--- Feedback Submission ---")
    guest_id = input("Enter your Guest ID: ")
    guest = next((g for g in guests if str(g.id) == guest_id), None)

    if guest:
        description = input("Enter Feedback Description: ")
        rating = int(input("Enter Rating (1-5): "))
        new_feedback = Feedback(len(feedbacks) + 1, guest, description, rating)
        feedbacks.append(new_feedback)
        print(f"Feedback submitted by Guest ID: {guest.id}")
    else:
        print("Guest not found.")

def handle_promotion(promotions):
    print("\n--- Promotion Management ---")
    print("1. Create Promotion")
    print("2. List Promotions")
    print("3. Return to Main Menu")
    choice = input("Enter your choice: ")

    if choice == "1":
        description = input("Enter Promotion Description: ")
        discount_rate = float(input("Enter Discount Rate (%): "))
        new_promotion = Promotion(len(promotions) + 1, description, discount_rate)
        promotions.append(new_promotion)
        print(f"Promotion created with ID: {new_promotion.id}")
    elif choice == "2":
        if promotions:
            for promo in promotions:
                print(f"ID: {promo.id}, Description: {promo.description}, Discount Rate: {promo.discountRate}%")
        else:
            print("No promotions available.")
    elif choice == "3":
        return

def authenticate(self, input_username, input_password):
    print(f"Expected password: {self.password}, Entered password: {input_password}")
    if self.username == input_username and self.password == input_password:
        print(f"User {self.username} logged in successfully.")
        return True
    else:
        print("Invalid username or password.")
        return False


if __name__ == "__main__":
    main_menu()