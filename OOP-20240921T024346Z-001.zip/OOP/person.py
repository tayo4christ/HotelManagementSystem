from abc import ABC

class Person(ABC):
    def __init__(self, id: int, name: str, email: str):
        self.id = id
        self.name = name
        self.email = email
