from Guest import Guest

class Feedback:
    def __init__(self, id: int, guest: Guest, description: str, rating: int):
        self.id = id
        self.guest = guest
        self.description = description
        self.rating = rating

    def submitFeedback(self):
        print(f"Feedback submitted by Guest {self.guest.id}: {self.description}, Rating: {self.rating}")