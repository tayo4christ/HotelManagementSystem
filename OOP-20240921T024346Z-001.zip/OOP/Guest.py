from person import Person 
from notification import Notification 
from room import Room 
from datetime import date 
from booking import Booking 
from invoice import Invoice 


# Class Guest
class Guest(Person, Notification):
    def __init__(self, id: int, name: str, email: str, phone: str, address: str):
        super().__init__(id, name, email)
        self.phone = phone
        self.address = address
        self.bookings = []  # List of Booking objects

    def makeBooking(self, room: 'Room', start_date: date, end_date: date):
        if room.checkAvailability(start_date, end_date):
            booking = Booking(len(self.bookings) + 1, self, room, start_date, end_date)
            self.bookings.append(booking)
            room.bookings.append(booking)
            print(f"Booking made for Room {room.number} from {start_date} to {end_date}")
            return booking
        else:
            print("Room not available for the selected dates.")
            return None

    def cancelBooking(self, booking_id: int):
        booking_to_cancel = next((b for b in self.bookings if b.id == booking_id), None)
        if booking_to_cancel:
            self.bookings.remove(booking_to_cancel)
            print(f"Booking {booking_id} cancelled.")
        else:
            print("Booking not found.")

    def viewInvoices(self):
        return [Invoice(i + 1, self, [b], b.charges) for i, b in enumerate(self.bookings)]

    def makePayment(self, invoice_id: int):
        invoice = next((inv for inv in self.viewInvoices() if inv.id == invoice_id), None)
        if invoice and not invoice.is_paid:
            invoice.is_paid = True
            for booking in invoice.bookings:
                booking.is_paid = True
            print(f"Payment for Invoice {invoice_id} completed.")
        else:
            print("Invoice not found or already paid.")
    
    def sendNotification(self, message: str):
        print(f"Notification for Guest {self.id}: {message}")

    # Method to request a service
    def requestService(self, service: Service, service_details: str):
        service.requestService(self, service_details)

