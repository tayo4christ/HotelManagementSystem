from room import Room 

class Maintenance:
    def __init__(self, id: int, room: Room, description: str, status: str):
        self.id = id
        self.room = room
        self.description = description
        self.status = status

    def scheduleMaintenance(self):
        print(f"Scheduled maintenance for Room {self.room.number}: {self.description}")
        self.status = "Scheduled"

    def completeMaintenance(self):
        print(f"Completed maintenance for Room {self.room.number}")
        self.status = "Completed"