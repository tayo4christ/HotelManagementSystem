from booking import Booking 

# Class Charge
class Charge:
    def __init__(self, id: int, booking: Booking, description: str, amount: float):
        self.id = id
        self.booking = booking
        self.description = description
        self.amount = amount